<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <title>About Us</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        /* Hero section*/ 
        .hero-section {
            position: relative;
            background-image: url('tea.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            margin-bottom: 45px;
        }

        .hero-section::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5); /* Adjust the alpha value to change the overlay opacity */
        }

        .hero-text {
            color: #ffffff;
            text-align: center;
            margin-bottom: 45px;
            margin-top: 45px;
        }

        .hero-text h1 {
            font-size: 13px;
            margin-bottom: 45px;
            margin-top: 45px;
            text-align: center;
        }

        .hero-text p {
            font-size: 12px;
            line-height: 1.5;
            text-align: center;
        }
    </style>
    <head>
  
  </style>
</head>
<body>


</head>
<body>
    <section class="hero-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto">
                    <div class="hero-text">
                        <h2>New way of Agriculture</h2>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>